Note:
- This example uses Peter Corke's Robotics Toolbox version in rvctools/ and has been tested in MATLAB 2018a
- The demo is run by calling demo_TPGMM_orientation01.m
- This example code is part of pbdlib-matlab, a repo containing several PbD tools: https://gitlab.idiap.ch/rli/pbdlib-matlab