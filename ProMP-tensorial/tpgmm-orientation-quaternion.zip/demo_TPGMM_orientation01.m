function demo_TPGMM_orientation01
% TPGMM with formulation to encode orientations, applied to a bimanual manipulation scenario.
% João Silvério, 2014
%
% Details:
%  -> In this demo, moving candidate frames are considered for encoding
%     the task (the frame of the opposed end-effector)
%  -> Quaternions are used to encode the orientation. The quaternion
%     product, implemented using a 4x4 quaternion matrix, is used to encode
%     relative orientations.
%  -> This code uses the Robotics Toolbox (Peter Corke) to handle
%     quaternions.
%
% Some usage details:
%  -> changing the value of model.nbFrames to either 1 or 2 encodes the
%     task in the frame of the opposite end-effector (nbFrames=1) or in the
%     frame of the opposite end-effector AND the frames of the bases (nbFrames=2)
%
%  -> setting perturbation = 1 turns on a perturbation in orientation. This
%     is a good way to see the effect of encoding the task in 1 or 2 frames.
close all
addpath('./m_fcts/');

% Start the local RTB
if(~exist('rvcpath'))
    run('rvctools/startup_rvc.m');
end

%% Load a demonstration from raw data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ------ Uncomment for a different demonstration
% load('data/Bimanual_demos/demo_clap1_Seg.mat');
% load('data/Bimanual_demos/demo_Sweep1_Seg.mat');  % 1 demo of sweeping task
load('data/Bimanual_demos/demo_allSweep_Seg.mat');	% 5 demos of sweeping

% -> loads:
%
%    1) a structure 's' [1 x nbSamples]:
%
%       -> s(n).d:      [nbD x 45] matrix with all the nbD datapoints of
%                       demonstration 'n'. These datapoints include time,
%                       positions, velocities and accelerations of both
%                       end-effectors.
%
%    2) 'dtSub' which contains the time step between each datapoint in the
%       demos.

%% Parameters
%%%%%%%%%%%%%%%

% ------ Variables for TP-GMM
model.nbStates  = 7;                % Number of States in the model
model.nbFrames  = 2;                 % Number of candidate frames of reference (1 or 2)
model.nbSamples = size(s,2);         % Number of demonstrations
model.nbVars	= [15 15];           % Dimension of each frame
model.nbVar		= max(model.nbVars); % Maximum dimension across all frames
model.kP        = 300;               % Stiffness gain (for DS-GMR)
model.kV        = 2*sqrt(model.kP);  % Damping gain (for DS-GMR)
model.kO        = 300;               % Orientational stiffness gain (for DS-GMR)
model.kW        = 2*sqrt(model.kO);  % Orientational damping gain (for DS-GMR)
model.dt        = dtSub;             % Time step between datapoints (from sub-sampling)
model.regFactor = 0.5E-1;            % A regularization term to minimize displacements along time

% ------ Variables for reproduction
demoPlot     = 4;                 % Index of the demonstration to be plotted
plotRateDemo = 15;                % Rate at which the demo will be plotted
plotRateRep  = 5;                % Rate at which the demo will be plotted
az           = 135.50;
el           = 20;                % azimuth and elevation - properties for the 3D figure
PlotAxis     = [-1 0.5 -1 1 -0.6 1];
perturbation = 0;                 % 1 - turns on a perturbation in the orientation of one of the robots
pertInstant  = 0.5;               % fraction of the time range of reproductions when the perturbation occurs
rframeRobot1 = [0 0.875/2 0];     % position of Robot1's base relative to virtual frame
rframeRobot2 = [0 -0.875/2 0];    % position of Robot2's base relative to virtual frame

% ------ Auxiliary variables for managing plotting and data generation
needsPlot = 1;

%% Ploting the original demonstrations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if(needsPlot)
    if(demoPlot>model.nbSamples)
        demoPlot=1;
    end
    
    DataIn = s(demoPlot).d;
    
    % ------ Initialization of data vectors from input file
    Robot1pos  = DataIn(:,2:4);         % <- ranges where the data is located in the original dataset
    Robot2pos  = DataIn(:,5:7);
    Robot1Quat = DataIn(:,8:11);
    Robot2Quat = DataIn(:,12:15);
    
    % ------ For plotting purposes, data will be converted to a common virtual frame
    % the reference frame is the mid-point between the 2 Robots
    Robot1pos = Robot1pos + repmat(rframeRobot1,size(Robot1pos,1),1);
    Robot2pos = Robot2pos + repmat(rframeRobot2,size(Robot2pos,1),1);
    
    % ------ Some auxiliary variables for plotting
    figure
    disp(['Showing the demonstrated task #' num2str(demoPlot) '...']);
    
    for n=1 : plotRateDemo : size(DataIn,1)
        
        % --- Creating Quaternions from 4-dim vectors
        q1=Quaternion(Robot1Quat(n,:));
        q2=Quaternion(Robot2Quat(n,:));
        
        % --- Plotting end-effector positions
        plot3(Robot1pos(n,1),Robot1pos(n,2),Robot1pos(n,3),'*');
        text(Robot1pos(n,1)+0.1,Robot1pos(n,2)+0.1,Robot1pos(n,3)+0.1,'\color[rgb]{0.2 0.5 0.2}Robot 1');
        hold on
        plot3(Robot2pos(n,1),Robot2pos(n,2),Robot2pos(n,3),'*');
        text(Robot2pos(n,1)+0.1,Robot2pos(n,2)+0.1,Robot2pos(n,3)+0.1,'\color{red}Robot 2');
        
        % --- Plotting end-effector orientations
        plot3Dframe(q1.R,Robot1pos(n,:));
        plot3Dframe(q2.R,Robot2pos(n,:));
        
        % --- Axes properties
        axis equal
        axis(PlotAxis);
        grid on
        view(az,el);
        xlabel('x'); ylabel('y'); zlabel('z');
        title(['Demonstrated task #' num2str(demoPlot) ' (t= ' num2str(DataIn(n,1)) 's)']);
        
        % --- Pausing + keeping current viewpoint for next graph
        pause(0.01);
        [az el]=view;
        hold off
    end
    
    clear DataIn Robot1pos Robot2pos Robot1Quat Robot2Quat q1 q2;
    disp('Demonstration finished. A TP-GMM model will be fit to the data...');
    disp('Press any key to continue.');
    pause
end

%% Estimating a TP-GMM
%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('Building task parameters...');

% ------ To represent the position of each effector in the other robot's base
% (Orientations don't need this since both bases are aligned)
Robot1relRobot2 = [0  0.875 0]; % position of Robot1's base relative to Robot2's
Robot2relRobot1 = [0 -0.875 0]; % position of Robot2's base relative to Robot1's

for n = 1 : model.nbSamples
    
    disp(['Demonstration #' num2str(n)]);
    
    % --- Positions and Quaternions of each robot in demonstration 'n'
    Robot1pos  = s(n).d(:,2:4);
    Robot2pos  = s(n).d(:,5:7);
    Robot1Quat = s(n).d(:,8:11);
    Robot2Quat = s(n).d(:,12:15);
    
    s(n).nbData = size(s(n).d,1);                   % Number of datapoints
    s(n).Data0  = zeros(model.nbVar, s(n).nbData);
    
    for k=1:s(n).nbData
        
        % --- Task Parameters (2nd frame)
        % The 2nd fame that is considered is the frame of both bases
        % (therefore, fixed)
        s(n).p(1,k).A    = eye(model.nbVar)*1E0;
        s(n).p(1,k).invA = inv(s(n).p(1,k).A);
        s(n).p(1,k).b    = zeros(model.nbVar,1);
        
        if (model.nbFrames == 2)
            % --- Task Parameters (1st frame)
            % A = [ 1 0   0    0  0		;	b = [ 0 			; Ri [3x3] -> rotation matrix of Robot i's effector relative to its base
            %       0 R2  0    0  0				  x1			; Qi [4x4] -> quaternion matrix representation of Robot i's effector orientation
            %       0 0   Q2   0  0               0 			; A[15x15]
            %       0 0   0    R1 0               x0			; b[15x1]
            %       0 0   0    0  Q1 ]            0 ]
            %
            % As defined in eq. XX in the Technical Report
            
            s(n).p(2,k).b = [0 ; Robot2pos(k,:)' ; zeros(4,1) ; Robot1pos(k,:)' ; zeros(4,1) ];
            s(n).p(2,k).A = eye(model.nbVar)*1E0;
            
            q = Quaternion(Robot2Quat(k,:));
            s(n).p(2,k).A(2:4,2:4) = q.R;
            s(n).p(2,k).A(5:8,5:8) = QuatToMatrix(q);     % saving the orientation as model parameter
            
            q = Quaternion(Robot1Quat(k,:));
            s(n).p(2,k).A(9:11,9:11) = q.R;
            s(n).p(2,k).A(12:15,12:15) = QuatToMatrix(q);
            
            s(n).p(2,k).invA = inv(s(n).p(2,k).A);
            
            
        end
        
    end
    
    % Build the data-set
    % -> The position of each Robot is converted to the opposite Robot's
    %    base frame.
    s(n).Data0 = [s(n).d(:,1) Robot1pos+repmat(Robot1relRobot2, s(n).nbData, 1) ...
        Robot1Quat Robot2pos+repmat(Robot2relRobot1, s(n).nbData, 1) Robot2Quat]';
    
end
fprintf('\n');

% ------ Define indexes of the GMR output
% The positions of the targets in the GMR output vector depend on the task
% parameters that are chosen.
% The below 'ranges' define these positions, according to what was set in
% s(n).Data0

Robot1PosRange = 2:4;
Robot2PosRange = 9:11;
Robot1QuatRange = 5:8;
Robot2QuatRange = 12:15;


% ------ Computing attractors in both position and orientation
% We extend DS-GMR to quaternion space by computing a 'quaternion
% attractor' for each end-effector, based on the assumed dynamics (Ko,Kw).
% Details can be found in Section XX of the Technical Report.

disp('Computing attractors and projecting data on local frames...');
for n=1:model.nbSamples
    
    nbD      = s(n).nbData;
    nbVarOut = model.nbVar - 1;
    DataTmp  = zeros(model.nbVar, nbD); % stores the attractors of demonstration 'n'
    
    % --- Positions, velocities and accelerations in demonstration 'n'
    % - In this example, the velocities and accelerations of each end-effector
    % were computed during the pre-processing of the data and loaded in 's'
    % - This data is needed to compute the attractors in position and
    % orientation
    RobotPositions         = s(n).Data0([Robot1PosRange Robot2PosRange],:);
    RobotVelocities        = s(n).d(:,22:27);  % velocities of both robots
    RobotAccelerations     = s(n).d(:,28:33);  % accelerations of both robots
    Robot1AngVelocities    = s(n).d(:,34:36);
    Robot1AngAccelerations = s(n).d(:,40:42);
    Robot2AngVelocities    = s(n).d(:,37:39);
    Robot2AngAccelerations = s(n).d(:,43:45);
    
    % --- Compute orientation and position attractors
    disp(['Demonstration #' num2str(n) '... Computing attractors...']);
    
    % --- Position attractor
    % Computed as XHAT = X + DX * kV / kP + DDX / kP
    disp('Position attractors...');
    K1d = [1, model.kV/model.kP, 1/model.kP];
    K   = kron(K1d,eye(size([Robot1PosRange Robot2PosRange],2)));
    DataTmp([1 Robot1PosRange Robot2PosRange],:) = [s(n).Data0(1,:); K * [RobotPositions ; RobotVelocities' ; RobotAccelerations']];
    
    disp('Orientation attractors...');
    % --- Orientation Attractor 1
    % The orientation attractors are computed according to eq. XX in the
    % Technical report:
    % QHAT = Q_EXP(DW * 1/(2*kO) + W * kW/kO)*Q
    
    for m=1:nbD
        dynamics_term  = (1/(2*model.kO)) * Robot1AngAccelerations(m,:) + (model.kW/(2*model.kO)) * Robot1AngVelocities(m,:);
        q_hat          = quaternionExp(dynamics_term)*Quaternion(s(n).Data0(Robot1QuatRange,m));
        q_hat_vec(m,:) = [q_hat.s q_hat.v];
    end
    DataTmp(Robot1QuatRange,:) = q_hat_vec';
    clear q_hat_vec
    
    % --- Orientation Attractor 2
    for m=1:nbD
        dynamics_term  = (1/(2*model.kO)) * Robot2AngAccelerations(m,:) + (model.kW/(2*model.kO)) * Robot2AngVelocities(m,:);
        q_hat          = quaternionExp(dynamics_term)*Quaternion(s(n).Data0(Robot2QuatRange,m));
        q_hat_vec(m,:) = [q_hat.s q_hat.v];
    end
    DataTmp(Robot2QuatRange,:) = q_hat_vec';
    clear q_hat_vec
    
    
    % --- Project data on local frames
    % Create 3rd order tensor data with XHAT;QHAT instead of X;Q
    for m=1:model.nbFrames
        %         Data(:,m,(n-1)*nbD+1:n*nbD) = s(n).p(m,n).A \ (DataTmp - repmat(s(n).p(m,n).b, 1, nbD));
        for k=1:nbD
            Data(:,m,(n-1)*nbD+k) = s(n).p(m,k).A \ (DataTmp(:,k) - s(n).p(m,k).b);
        end
    end
    
end

fprintf('\nParameters estimation of tensor GMM with EM:');
model = init_tensorGMM_timeBased(Data, model);  % Initialization
model = EM_tensorGMM(Data, model);
disp('Press any key to continue.');
pause

%% Adding a Regularization term to the resulting local models
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for n=1:model.nbStates
    for m=1:model.nbFrames
        model.Sigma(:,:,m,n) = model.Sigma(:,:,m,n) + model.regFactor * eye(model.nbVar);
    end
end

%% Computing the demonstrated relative positions and orientations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

t_gmr = s(demoPlot).d(:,1)';      % time range that will be used to perform GMR
% t_gmr = 0:model.dt:5;
nbD   = size(t_gmr,2);          % number of datapoints in the range

% ------ Initializing figure for plotting
h1=figure;
subplot(2,2,[1,3]); hold on; grid on; axis equal;
xlabel('x'); ylabel('y'); zlabel('z'); view(az,el);
subplot(222); set(gca,'xlim',[min(t_gmr) max(t_gmr)]); hold on; ylabel('w'); title('Distance between end-effectors.'); xlabel('t');
subplot(224); set(gca,'xlim',[min(t_gmr) max(t_gmr)]); hold on; ylabel('x'); title('Relative orientation.'); yaxis([-1,1]); xlabel('t');


% ------ Compute distance between effectors and relative orientation in the demonstrations
for n=1:model.nbSamples
    
    RobotDistance = zeros(nbD,1); % distance between the end-effectors
    RobotOrient   = zeros(nbD,4); % relative orientation between end-effectors
    
    for m = 1:nbD
        RobotDistance(m)  = norm(s(n).d(m,2:4)-(s(n).d(m,5:7)+Robot2relRobot1));
        q0               = Quaternion(s(n).d(m,8:11));
        q1               = Quaternion(s(n).d(m,12:15));
        q_r              = q1.inv*q0;
        RobotOrient(m,:)  = [q_r.s q_r.v];
    end
    
    subplot(222); plot(model.dt:model.dt:nbD*model.dt,RobotDistance);
    subplot(224);
    plot(model.dt:model.dt:nbD*model.dt,RobotOrient(:,1),'b');
    plot(model.dt:model.dt:nbD*model.dt,RobotOrient(:,2),'g');
    plot(model.dt:model.dt:nbD*model.dt,RobotOrient(:,3),'k');
    plot(model.dt:model.dt:nbD*model.dt,RobotOrient(:,4),'m');
end


%% Reproduction for the set of parameters used to train the model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('Reproductions...');

% ------ Initialization of variables for the integration
dx     = zeros(6,nbD);              % stores linear velocities
do1    = zeros(3,nbD);              % stores angular velocities of Robot 1
do2    = zeros(3,nbD);              % stores angular velocities of Robot 2
x      = zeros(model.nbVar,nbD);    % stores the current state of each robot

% ------ Perturbation variables
% This variable simulates a torque applied on the end-effector of one of
% the robots at a given point in the reproduction.
Torque_ext = zeros(3,nbD);
model.nbVarOut=model.nbVar;

for n=1 : 1 : nbD
    
    % --- Add an orientation perturbation
    if perturbation==1 && n==round(pertInstant*nbD)
        Torque_ext(:,n) = rand(3,1)*5000;
        disp(['Adding perturbation in orientation at t=' num2str(n*model.dt)]);
    end
    
    % --- Task Parameters
    if n==1
        for m=1:model.nbFrames
            pTmp(m,1).b = s(1).p(m,n).b;
            pTmp(m,1).A = s(1).p(m,n).A;
        end
    else
        
        % Frame #1 - bases of the robots
        pTmp(1,1).b = s(1).p(1,n).b;
        pTmp(1,1).A = s(1).p(1,n).A;
        
        % Frame #2
        if (model.nbFrames == 2)
            pTmp(2,1).b = [0; (x(Robot2PosRange,n-1)' + Robot1relRobot2)' ; zeros(4,1) ; (x(Robot1PosRange,n-1)'+Robot2relRobot1)' ; zeros(4,1) ];
            
            q1 = Quaternion(x(Robot1QuatRange,n-1));
            q1 = q1/q1.norm;
            q2 = Quaternion(x(Robot2QuatRange,n-1));
            q2 = q2/q2.norm;
            
            pTmp(2,1).A(2:4,2:4)     = q2.R;
            pTmp(2,1).A(5:8,5:8)     = QuatToMatrix(q2);
            pTmp(2,1).A(9:11,9:11)   = q1.R;
            pTmp(2,1).A(12:15,12:15) = QuatToMatrix(q1);
        end
        
    end
    rr.p=pTmp;
    
    % --- Get GMR output for current t
    r       = estimateAttractorPath(t_gmr(n), model, rr);
    targets = [t_gmr(n) ; r.currTar]';
    
    % --- Normalizing Quaternions
    targets(Robot1QuatRange) = targets(Robot1QuatRange)/norm(targets(Robot1QuatRange));
    targets(Robot2QuatRange) = targets(Robot2QuatRange)/norm(targets(Robot2QuatRange));
    
    % --- Integrate MSD equations
    if n==1
        x(:,n)   = targets';
        
    else
        x(1,n) = targets(1);  % just the time dimension, irrelevant
        
        % --- Define position targets and previous orientations
        x_prev    = [x(Robot1PosRange,n-1)  ; x(Robot2PosRange,n-1)];
        x_targets = [targets(Robot1PosRange)  targets(Robot2PosRange)]';
        
        % --- Integrate positions
        ddx         = model.kP * (x_targets - x_prev) - model.kV * dx(:,n-1) + [zeros(3,1);Torque_ext(:,n)*0.05];
        dx(:,n)     = dx(:,n-1) + model.dt * ddx;
        x([Robot1PosRange Robot2PosRange],n) = x_prev + model.dt * dx(:,n);
        
        % --- Define orientation targets and previous orientations
        o_prev    = [x(Robot1QuatRange,n-1) ; x(Robot2QuatRange,n-1)];
        o_targets = [targets(Robot1QuatRange) targets(Robot2QuatRange)]';
        
        % --- Integrate quaternion for WAM0
        % Quaternion integration makes use of the logarithmic map
        % implemented by the function 'quaternionLog' in order to obtain an
        % angular velocity from a displacement in quaternion space.
        q_prev        = Quaternion(o_prev(1:4));
        ddo           = model.kO * 2 * quaternionLog(Quaternion(o_targets(1:4))*q_prev.inv)' - model.kW * do1(:,n-1);
        do1(:,n)      = do1(:,n-1) + model.dt * ddo;
        q_curr0       = quaternionExp((model.dt/2)*do1(:,n)') * q_prev;
        x(Robot1QuatRange,n) = [q_curr0.s q_curr0.v]';
        
        % --- Integrate quaternion for WAM1
        q_prev        = Quaternion(o_prev(5:8));
        ddo           = model.kO * 2 * quaternionLog(Quaternion(o_targets(5:8))*q_prev.inv)' - model.kW * do2(:,n-1) + Torque_ext(:,n);
        do2(:,n)      = do2(:,n-1) + model.dt * ddo;
        q_curr1       = quaternionExp((model.dt/2)*do2(:,n)') * q_prev;
        x(Robot2QuatRange,n) = [q_curr1.s q_curr1.v]';
        
    end
    
    % --- Plotting the frames in 3D at every 'plotRateRep'-th iteration
    if(rem(n,plotRateRep)==0)
        
        figure(h1);
        subplot(2,2,[1,3]);
        
        % --- Plot Robot1 end-effector
        Robot1Pos = x(Robot1PosRange,n)' + rframeRobot2;    % convert to a common frame
        plot3(Robot1Pos(1), Robot1Pos(2), Robot1Pos(3), '*'); hold on % plot Position
        text(Robot1Pos(1), Robot1Pos(2), Robot1Pos(3), '\color[rgb]{0.2 0.5 0.2}Robot 1');
        q1 = Quaternion(x(Robot1QuatRange,n));
        plot3Dframe(q1.R, Robot1Pos);  % plot orientation
        
        % --- Plot Robot2 end-effector
        Robot2Pos = x(Robot2PosRange,n)' + rframeRobot1;    % convert to a common frame
        plot3(Robot2Pos(1), Robot2Pos(2), Robot2Pos(3), '*');
        text(Robot2Pos(1), Robot2Pos(2), Robot2Pos(3), '\color{red}Robot 2');
        q2 = Quaternion(x(Robot2QuatRange,n));
        plot3Dframe(q2.R, Robot2Pos);
        
        axis equal
        axis([-1.0 0 -0.8 0.8 -0.3 0.8]);
        grid on
        view(az,el);
        xlabel('x'); ylabel('y'); zlabel('z');
        pause(0.01);
        [az el] = view;
        hold off
        
        % --- Plot relative positions and orientations
        subplot(222);
        dist = norm(Robot1Pos-Robot2Pos);
        plot(n*model.dt, dist,'r*');
        
        subplot(224);
        q=q2.inv*q1;
        plot(n*model.dt,q.s,'b*');
        plot(n*model.dt,q.v(1),'g*');
        plot(n*model.dt,q.v(2),'k*');
        plot(n*model.dt,q.v(3),'m*');
        
    end
end
