function [qMatrix] = QuatToMatrix(q)
% An auxiliary function to build a Quaternion Matrix
%
% João Silvério, created: 2014 (modified: 2016)

qMatrix = [q.s    -q.v(1) -q.v(2) -q.v(3);
	q.v(1) q.s     -q.v(3) q.v(2);
	q.v(2) q.v(3)  q.s     -q.v(1);
	q.v(3) -q.v(2) q.v(1)  q.s   ];
